Для создания плейлиста создайте текстовый файл в папке playlists.
Далее скопируйте в текстовый файл путь к аудиофайлу.
Каждый путь должен начинаться с новой строки.
Поддерживаются файлы разрешения .mp3 .wav .ogg


To create a playlist, create a text file in the playlists folder.
Next, copy the path to the audio file into a text file.
Each path must start on a new line.
Resolution files .mp3 .wav .ogg are supported