import pygame


class Frame:
    def __init__(self, window, width, height, coord, elements, color=(0, 0, 0)):
        self.window = window
        self.width, self.height = width, height
        self.surf = pygame.Surface((width, height))
        self.width, self.height = width, height
        self.coord = coord
        self.elements = []
        self.elements_height = 0
        for i in elements:
            self.elements.append(i)
            self.elements_height += i.rect.height
        self.color = color
        self.special_elements = []

    def add_element(self, element):
        self.elements.append(element)
        self.elements[-1].surf = self.surf
        self.elements_height += element.rect.height
        print(self.elements_height)
        if self.elements_height >= int(self.height * 0.9):
            None

    def add_special_elements(self, element):
        self.special_elements.append(element)
        self.special_elements[-1].surf = self.surf

    def render(self, shift_y=0):
        self.surf.fill(self.color)
        for i in self.elements:
            i.render(shift_y)
        self.window.surf.blit(self.surf, self.coord)

    def active_element(self, mouse_pos):
        for i in self.elements:
            if i.in_rect(mouse_pos[0] - self.coord[0], mouse_pos[1] - self.coord[1]):
                return i
        else:
            return None

    def reset(self):
        self.elements = []
        self.elements_height = 0


class Window:
    def __init__(self, sc, width, height, coord, elements, color=(77, 77, 77)):
        self.sc = sc
        self.width = width
        self.height = height
        self.coord = coord
        self.surf = pygame.Surface((width, height))
        self.elements = elements
        for i in self.elements:
            i.surf = self.surf
        self.color = color

    def add_element(self, element):
        self.elements.append(element)

    def render(self):
        self.surf.fill(self.color)
        for i in self.elements:
            self.surf.blit(i.surf, i.coord)
        self.sc.blit(self.surf, self.coord)

    def active_frame(self, mouse_pos):
        for i in self.elements:
            if mouse_pos[0] in range(i.coord[0], i.coord[0] + i.width) and mouse_pos[1] in range(i.coord[1], i.coord[1] + i.height):
                return i
        else:
            return None
