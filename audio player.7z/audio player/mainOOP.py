import pygame
from button import *
from window import Window, Frame
from os import sep, getcwd, listdir
from sys import exit


sc = pygame.display.set_mode((1280, 720))
clock = pygame.time.Clock()
FPS = 60
WIDTH, HEIGHT = 1280, 720
pygame.mixer.pre_init(44100, -16, 1, 512)
pygame.mixer.init()


class Player:
    def update(self):
        y = 0
        for i in listdir(getcwd() + sep + "playlists"):
            self.playlist_frame.add_element(Button(None, int(WIDTH * 0.01), int(HEIGHT // 20 + HEIGHT * 0.07 * y),
                i.split(".")[0], WIDTH // 50, command=self.open_playlist, width=int(WIDTH * 0.98),))
            y += 1

    def open_playlist(self):
        if self.element:
            with open(self.path + self.element.text + ".txt") as f:
                self.playlist = f.read().split("\n")
                self.music_frame.elements = []
                y = 0
                for i in self.playlist:
                    self.music_frame.add_element(Button(None, int(WIDTH * 0.01), int(HEIGHT // 20 + HEIGHT * 0.07 * y),
                        i.split("\\")[-1], WIDTH // 50, command=self.play, width=int(WIDTH * 0.98)))
                    y += 1
                self.surf.elements[1] = self.music_frame

    def play(self, path=None):
        if self.music:
            self.music.stop()
        self.music = pygame.mixer.Sound(path) if path else pygame.mixer.Sound(self.playlist[self.music_frame.elements.index(self.element)])
        self.index = self.playlist.index(path) if path else self.music_frame.elements.index(self.element)
        self.music.set_volume(self.volume_bar.value)
        self.music.play()
        self.pause = False

    def play_button(self):
        if self.music:
            if self.pause:
                pygame.mixer.unpause()
            else:
                pygame.mixer.pause()
            self.pause = not self.pause

    def next_track(self):
        if self.playlist:
            self.index = self.index + 1 if len(self.playlist) - 1 > self.index else 0
            self.play(self.playlist[self.index])

    def prev_track(self):
        if self.playlist:
            self.index -= 1
            if self.index < 0:
                self.index = len(self.playlist) - 1
            self.play(self.playlist[self.index])

    def change_volume(self):
        self.volume_bar.change_value(self.coord[0])
        if self.music:
            self.music.set_volume(self.volume_bar.value)

    def __init__(self):
        self.surf = Window(sc, WIDTH, HEIGHT, (0, 0), [])
        self.main_frame = Frame(self.surf, WIDTH, HEIGHT // 6, (0, HEIGHT - HEIGHT // 6), [])
        self.playlist_frame = Frame(self.surf, WIDTH, HEIGHT - HEIGHT // 6, (0, 0), [])
        self.music_frame = Frame(self.surf, WIDTH, HEIGHT - HEIGHT // 6, (0, 0), [])
        self.main_frame.add_element(Button(None, int(WIDTH * 0.465), int(HEIGHT // 6 * 0.15), "  ||  ", WIDTH // 40,
                                           command=self.play_button, width=int(WIDTH * 0.07)))
        self.main_frame.add_element(Button(None, int(WIDTH * 0.55), int(HEIGHT // 6 * 0.15), "  >  ", WIDTH // 40,
                                           command = self.next_track, width=int(WIDTH * 0.07)))
        self.main_frame.add_element(Button(None, int(WIDTH * 0.38), int(HEIGHT // 6 * 0.15), "  <  ", WIDTH // 40,
                                           command=self.prev_track, width=int(WIDTH * 0.07)))
        self.volume_bar = ProgressBar(None, int(WIDTH * 0.7), int(HEIGHT // 6 * 0.3), int(WIDTH * 0.25), HEIGHT // 30, 0.5, 1,
                                      command=self.change_volume)
        self.main_frame.add_element(self.volume_bar)
        self.main_frame.add_element(ProgressBar(None, int(WIDTH * 0.38), int(HEIGHT // 8 * 0.9), int(WIDTH * 0.24),
                                                HEIGHT // 30, 0, 1))
        self.surf.add_element(self.main_frame)
        self.music_frame.surf.fill((10, 10, 10))
        self.playlist_frame.surf.fill((10, 10, 10))
        self.update()
        self.surf.add_element(self.playlist_frame)
        self.coord = (0, 0)  #Координаты курсора
        self.frame = None  #frame на который наведен курсор
        self.element = None  #Элемент на который наведен курсор
        self.playlist = []
        self.index = 0
        self.music = None
        self.pause = False
        self.path = getcwd() + sep + "playlists" + sep
        #self.open_playlist()

    def main(self):
        while True:
            self.coord = pygame.mouse.get_pos()
            self.frame = self.surf.active_frame(self.coord)
            if self.frame:
                self.element = self.frame.active_element(self.coord)
            for i in pygame.event.get():
                if i.type == pygame.QUIT:
                    exit()
                elif i.type == pygame.MOUSEBUTTONDOWN:
                    self.mouse_key = pygame.mouse.get_pressed()
                    if self.mouse_key[0] and self.element:
                        self.element.command()
                    elif self.mouse_key[2]:
                        self.surf.elements[1] = self.playlist_frame
            self.main_frame.render()
            self.surf.elements[1].render()
            self.surf.render()
            if self.element:
                pygame.draw.rect(sc, (255, 10, 40),
                    (self.element.rect.x + self.frame.coord[0], self.element.rect.y + self.frame.coord[1], self.element.rect.width, self.element.rect.height), 2)
            pygame.display.flip()
            clock.tick(FPS)


player = Player()
player.main()
