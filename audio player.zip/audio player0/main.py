import pygame
from button import *
from window import Window
from os import sep, getcwd, listdir
from sys import exit

playing_music = ""
now_playing = None
pause = False
WIDTH, HEIGHT = 1280, 720
FPS = 60
value = 0.5
cur_lenght = 0
y = 0

pygame.font.init()
music_font = pygame.font.SysFont("Lucida Console", WIDTH // 40)
music_name = music_font.render(playing_music, True, (20, 160, 60))
clock = pygame.time.Clock()
sc = pygame.display.set_mode((WIDTH , HEIGHT))
panel_surf = pygame.Surface((WIDTH, HEIGHT * 0.13))
music_surf = pygame.Surface((WIDTH, int(HEIGHT - HEIGHT * 0.26)))
music_surf.fill((50, 50, 50))
panel_surf.fill((40, 40, 40))
pygame.mixer.init()
pygame.display.set_caption("Audio player")
upd_button = Button(sc, int(WIDTH * 0.02), int(HEIGHT * 0.02), "Обновить", WIDTH // 40, width=WIDTH - int(WIDTH * 0.54))
new_playlist = Button(sc, int(WIDTH * 0.52), int(HEIGHT * 0.02), "Новый плейлист", WIDTH // 40, width=WIDTH - int(WIDTH * 0.54))
stop_button = Button(sc, int(WIDTH * 0.465), int(HEIGHT - HEIGHT * 0.12), "  ||  ", WIDTH // 40, width=int(WIDTH * 0.07))
next_button = Button(sc, int(WIDTH * 0.55), int(HEIGHT - HEIGHT * 0.12), "  >  ", WIDTH // 40, width=int(WIDTH * 0.07))
prev_button = Button(sc, int(WIDTH * 0.38), int(HEIGHT - HEIGHT * 0.12), "  <  ", WIDTH // 40, width=int(WIDTH * 0.07))
volume = ProgressBar(sc, int(WIDTH * 0.7), int(HEIGHT - HEIGHT * 0.12), int(WIDTH * 0.25), Button.get_height(WIDTH // 40), 0.5, 1)
lenght = ProgressBar(sc, int(WIDTH * 0.38), int(HEIGHT - HEIGHT * 0.035), int(WIDTH * 0.24), int(HEIGHT * 0.02), 0, 1)

main_buttons = [upd_button, new_playlist, next_button, prev_button, stop_button, volume, lenght]
main_window = Window(sc, WIDTH, HEIGHT, (0, 0), main_buttons)
buttons = []


def buttons_render():
    global main_buttons, buttons
    for i in buttons:
        i.render()
    sc.blit(panel_surf, (0, int(HEIGHT - HEIGHT * 0.13)))
    for i in main_buttons:
        i.render()


def update():
    global buttons, upd_button, sc, buttons_render, music_surf, main_window
    buttons_render()
    cur_dir = getcwd() + sep + "playlists" + sep
    buttons = []
    y = 1
    for i in listdir(cur_dir):
        main_window.add_element(Button(music_surf, int(WIDTH * 0.02), int(HEIGHT * 0.1 + HEIGHT * 0.08 * y),
                                       i[0:i.index(".")], WIDTH // 50, width=WIDTH - int(WIDTH * 0.04),
                                       description="playlist"))
        y += 1


def play(path, value):
    global now_playing, cur_lenght, lenght, pause
    try:
        now_playing = pygame.mixer.Sound(path)
        now_playing.set_volume(value)
        now_playing.play()
        pause = False
        cur_lenght = 0
        lenght.max_value = now_playing.get_length()
        music_name = music_font.render(playing_music.split(sep)[-1], True, (190, 160, 60))
        panel_surf.fill((40, 40, 40))
        panel_surf.blit(music_name, (int(WIDTH * 0.03), int(HEIGHT * 0.05)))
    except FileNotFoundError:
        print("Файл не найден")


def next_music(mus_list, mus):
    index = mus_list.index(mus)
    if index + 1 > len(mus_list) - 1:
        return mus_list[0]
    return mus_list[index + 1]


def prev_music(mus_list, mus):
    index = mus_list.index(mus)
    return mus_list[index - 1]


def render():
    global sc, panel_surf, buttons_render
    sc.fill((0, 0, 0))
    sc.blit(panel_surf, (0, int(HEIGHT - HEIGHT * 0.13)))
    music_surf.fill((50, 50, 50))
    sc.blit(music_surf, (0, int(HEIGHT * 0.131)))
    buttons_render()


def add_playlist(name):
    f = open(getcwd() + sep + "playlists" + sep + name + ".txt", "w")
    f.close()


update()
render()
while True:
    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            exit()
        elif i.type == pygame.MOUSEWHEEL:
            y += i.y * 20
            if not(y >= 20):
                for j in buttons:
                        j.rect.y += i.y * 20
            else:
                y = 0
            render()
        elif i.type == pygame.MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pressed()
            if mouse[0]:
                if pos[1] in range(int(HEIGHT * 0.131), int(HEIGHT - HEIGHT * 0.131)):
                    for i in buttons:
                        if i.in_rect(pos[0], pos[1] - int(HEIGHT * 0.131)) and i.description == "playlist":
                            with open(getcwd() + sep + "playlists" + sep + i.text + ".txt", "r") as f:
                                music = f.read().split("\n")
                                buttons = []
                                y = 1
                                for i in music:
                                    main_window.add_element(Button(None, int(WIDTH * 0.02), int(HEIGHT * 0.1 + HEIGHT * 0.08 * y),
                                                                   i.split(sep)[-1], WIDTH // 50, width=WIDTH - int(WIDTH * 0.04),
                                                          description=i))
                                    y += 1
                                music_surf.fill((50, 50, 50))
                                upd_button.change_text("Назад")
                                buttons_render()
                            break
                        elif i.in_rect(pos[0], pos[1] - int(HEIGHT * 0.131)):
                            playing_music = i.description
                            if now_playing:
                                now_playing.stop()
                            play(playing_music, value)
                else:
                    if upd_button.in_rect(*pos):
                        y = 0
                        update()
                        upd_button.change_text("Обновить")
                        music_surf.fill((50, 50, 50))
                        buttons_render()
                        sc.blit(music_surf, (0, int(HEIGHT * 0.131)))
                    elif stop_button.in_rect(*pos) and now_playing:
                        pause = not pause
                        if pause:
                            pygame.mixer.pause()
                        else:
                            pygame.mixer.unpause()
                    elif next_button.in_rect(*pos):
                        playing_music = next_music(music, playing_music)
                        pygame.mixer.stop()
                        play(playing_music, value)
                    elif prev_button.in_rect(*pos):
                        playing_music = prev_music(music, playing_music)
                        pygame.mixer.stop()
                        play(playing_music, value)
                    elif volume.in_rect(*pos):
                        value = (pos[0] - volume.x) / volume.width * volume.max_value
                        volume.value = value
                        volume.render()
                        if now_playing:
                            now_playing.set_volume(value)

    if playing_music:
        if not pygame.mixer.get_busy():
            if music.index(playing_music) == len(music) - 1:
                playing_music = music[0]
            else:
                playing_music = music[music.index(playing_music) + 1]
            play(playing_music, value)
        if not pause:
            cur_lenght += 1 / clock.get_fps()
            lenght.value = cur_lenght
    pos = pygame.mouse.get_pos()
    for i in main_buttons:
        if i.in_rect(*pos):
            pygame.draw.rect(sc, (250, 10, 50), (i.rect.x, i.rect.y, i.rect.width - 1, i.rect.height - 1), 2)
            break
    else:
        if pos[1] in range(int(HEIGHT * 0.131), int(HEIGHT - HEIGHT * 0.131)):
            for i in buttons:
                if i.in_rect(pos[0], pos[1] - int(HEIGHT * 0.135)):
                    pygame.draw.rect(music_surf, (250, 10, 50), (i.rect.x, i.rect.y, i.rect.width - 1, i.rect.height - 1), 2)
                    break
            else:
                buttons_render()
        else:
            buttons_render()
    sc.blit(music_surf, (0, int(HEIGHT * 0.131)))
    lenght.render()
    main_window.render()
    pygame.display.update()
    clock.tick(FPS)
